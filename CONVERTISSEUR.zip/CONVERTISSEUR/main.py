from tkinter import *
from tkinter.messagebox import *
from tkinter.filedialog import * 
from functions import convertValueToBinary as cvtb, convertValueToHexadecimal as cvth, convertValueToOctal as cvto, convertHexadecimalToBinary as chtb, convertHexadecimalToOctal as chto 
import webbrowser as wb
import os as command
import platform

root = Tk()
width = 1000
height = 250
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width / 2) - (width / 2)
y = (screen_height / 2) - (height / 2)
root.title("CONVERTISSEUR")
root.geometry('{}x{}+{}+{}'.format(width, height, int(x), int(y)))
root.resizable(width=False, height=False)
root.config(bg="#080807")
root.iconbitmap("IMG/calculator.ico")

def choiceCommand(*args):
   def functionVerifyIntegrityValueDecimal(convert):
      if enterValue.get() != "":
         try:
            value = int(enterValue.get())
         except NameError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except TypeError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except ValueError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         else:
            if convert == "cvtb":
               if len(enterValue.get()) <= 40: 
                  label.config(text=(cvtb(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE NOMBRE NE DOIT PAS DÉPASSER 40 CHIFFRES..."), foreground="#FF0000")
            elif convert == "cvth":
               if len(enterValue.get()) <= 160:
                  label.config(text=(cvth(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE NOMBRE NE DOIT PAS DÉPASSER 160 CHIFFRES..."), foreground="#FF0000")
            elif convert == "cvto":
               if len(enterValue.get()) <= 120:
                  label.config(text=(cvto(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE NOMBRE NE DOIT PAS DÉPASSER 120 CHIFFRES..."), foreground="#FF0000")
            else:
               label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
      else:
         label.config(text=(""))

   def functionVerifyIntegrityValueString(convert):
      if enterValue.get() != "":
         try:
            value = str(enterValue.get())
         except NameError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except TypeError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except ValueError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         else:
            if convert == "cvtb":
               if len(enterValue.get()) <= 18: 
                  label.config(text=(cvtb(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CHAÎNE NE DOIT PAS DÉPASSER 18 CARACTÈRES..."), foreground="#FF0000")
            elif convert == "cvth":
               if len(enterValue.get()) <= 53:
                  label.config(text=(cvth(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CHAÎNE NE DOIT PAS DÉPASSER 53 CARACTÈRES..."), foreground="#FF0000")
            elif convert == "cvto":
               if len(enterValue.get()) <= 38:
                  label.config(text=(cvto(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CHAÎNE NE DOIT PAS DÉPASSER 38 CARACTÈRES..."), foreground="#FF0000")
            else:
               label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
      else:
         label.config(text=(""))

   def functionVerifyIntegrityValueHexadecimal(convert):
      if enterValue.get() != "":
         try:
            value = str(enterValue.get())
         except NameError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except TypeError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except ValueError:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         except:
            label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
         else:
            if convert == "chtb":
               if len(enterValue.get()) <= 34: 
                  label.config(text=(chtb(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CODE NE DOIT PAS DÉPASSER 34 CARACTÈRES..."), foreground="#FF0000")
            elif convert == "upper":
               if len(enterValue.get()) <= 136:
                  label.config(text=(value.upper()))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CODE NE DOIT PAS DÉPASSER 136 CARACTÈRES..."), foreground="#FF0000")
            elif convert == "chto":
               if len(enterValue.get()) <= 102:
                  label.config(text=(chto(value)))
               else:
                  label.config(text=("LA LONGEUR DE VOTRE CODE NE DOIT PAS DÉPASSER 102 CARACTÈRES..."), foreground="#FF0000")
            else:
               label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
      else:
         label.config(text=(""))
   global val
   if val == 1:
      label.config(foreground="#FFFFFF")
   elif val == 2:
      label.config(foreground="#000000")
   if varTwo.get() == 1:
      if varOne.get() == 1:
         functionVerifyIntegrityValueString("cvtb")
      elif varOne.get() == 2:
         functionVerifyIntegrityValueString("cvth")
      elif varOne.get() == 3:
         functionVerifyIntegrityValueString("cvto")
      else:
         label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
   elif varTwo.get() == 2:
      if varOne.get() == 1:
         functionVerifyIntegrityValueDecimal("cvtb")
      elif varOne.get() == 2:
         functionVerifyIntegrityValueDecimal("cvth")
      elif varOne.get() == 3:
         functionVerifyIntegrityValueDecimal("cvto")
      else:
         label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
   elif varTwo.get() == 3:
      if varOne.get() == 1:
         if chtb(enterValue.get()) != 5 and enterValue.get() != "":
            functionVerifyIntegrityValueHexadecimal("chtb")
         else:
            if enterValue.get() != "":
               label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
            else:
               label.config(text="")
      elif varOne.get() == 2:
         if chtb(enterValue.get()) != 5 and enterValue.get() != "":
            functionVerifyIntegrityValueHexadecimal("upper")
         else:
            if enterValue.get() != "":
               label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
            else:
               label.config(text="")
      elif varOne.get() == 3:
         if chtb(enterValue.get()) != 5 and enterValue.get() != "":
            functionVerifyIntegrityValueHexadecimal("chto")
         else:
            if enterValue.get() != "":
               label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
            else:
               label.config(text="")
      else:
         label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
   else:
      label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT D'ENTRÉE..."), foreground="#FF0000")
         
def save():
	def functionVerifyIntegrityValueDecimal(convert):
		if enterValue.get() != "":
			try:
				value = int(enterValue.get())
			except NameError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except TypeError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except ValueError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			else:
				if convert == "cvtb":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvtb(value)))
						command.system("start SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvtb(value)))
						command.system(".\\SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "cvth":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvth(value)))
						command.system("start SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvth(value)))
						command.system(".\\SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "cvto":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvto(value)))
						command.system("start SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvto(value)))
						command.system(".\\SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				else:
					label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
		else:
			label.config(text=(""))

	def functionVerifyIntegrityValueString(convert):
		if enterValue.get() != "":
			try:
				value = str(enterValue.get())
			except NameError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except TypeError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except ValueError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			else:
				if convert == "cvtb":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvtb(value)))
						command.system("start SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvtb(value)))
						command.system(".\\SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "cvth":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvth(value)))
						command.system("start SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvth(value)))
						command.system(".\\SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "cvto":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvto(value)))
						command.system("start SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, cvto(value)))
						command.system(".\\SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				else:
					label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
		else:
			label.config(text=(""))

	def functionVerifyIntegrityValueHexadecimal(convert):
		if enterValue.get() != "":
			try:
				value = str(enterValue.get())
			except NameError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except TypeError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except ValueError:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			except:
				label.config(text="UNE ERREUR EST SURVENUE...", foreground="#FF0000")
			else:
				if convert == "chtb":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, chtb(value)))
						command.system("start SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, chtb(value)))
						command.system(".\\SAVE/BINARY-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "upper":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, value.upper()))
						command.system("start SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, value.upper()))
						command.system(".\\SAVE/HEXA-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
				elif convert == "chto":
					if platform.system() == "Windows":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, chto(value)))
						command.system("start SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")
					elif platform.system() == "Linux":
						command.system("echo {} = {} > SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt".format(value, chto(value)))
						command.system(".\\SAVE/OCTAL-%DATE:~0,2%-%DATE:~3,2%-%DATE:~6,10%_%TIME:~0,2%-%TIME:~3,2%.txt")

				else:
					label.config("UNE ERREUR EST SURVENUE...", foreground="#FF0000")
		else:
			label.config(text=(""))
	global val
	if val == 1:
		label.config(foreground="#FFFFFF")
	elif val == 2:
		label.config(foreground="#000000")
	if varTwo.get() == 1:
		if varOne.get() == 1:
			functionVerifyIntegrityValueString("cvtb")
		elif varOne.get() == 2:
			functionVerifyIntegrityValueString("cvth")
		elif varOne.get() == 3:
			functionVerifyIntegrityValueString("cvto")
		else:
			label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
	elif varTwo.get() == 2:
		if varOne.get() == 1:
			functionVerifyIntegrityValueDecimal("cvtb")
		elif varOne.get() == 2:
			functionVerifyIntegrityValueDecimal("cvth")
		elif varOne.get() == 3:
			functionVerifyIntegrityValueDecimal("cvto")
		else:
			label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
	elif varTwo.get() == 3:
		if varOne.get() == 1:
			if chtb(enterValue.get()) != 5 and enterValue.get() != "":
					functionVerifyIntegrityValueHexadecimal("chtb")
			else:	
				if enterValue.get() != "":
					label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
				else:
					label.config(text="")
		elif varOne.get() == 2:
			if chtb(enterValue.get()) != 5 and enterValue.get() != "":
				functionVerifyIntegrityValueHexadecimal("upper")
			else:
				if enterValue.get() != "":
					label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
				else:
					label.config(text="")
		elif varOne.get() == 3:
			if chtb(enterValue.get()) != 5 and enterValue.get() != "":
				functionVerifyIntegrityValueHexadecimal("chto")
			else:
				if enterValue.get() != "":
					label.config(text="VOTRE CODE HÉXADÉCIMAL N'EST PAS ACCEPTABLE...", foreground="#FF0000")
				else:
					label.config(text="")
		else:
			label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT DE SORTIE..."), foreground="#FF0000")
	else:
		label.config(text=("VOUS DEVEZ CHOISIR LE FORMAT D'ENTRÉE..."), foreground="#FF0000")

def choice(event):
   choiceCommand()
def terminate():
   if askyesno("QUITTER", "Êtes-vous sûr ?", icon="warning"):
      root.destroy()
def controlTheme():
   global val
   if val == 1:
      root.config(bg="#FFFFFF")
      R1.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      R2.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      R3.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      B1.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      B2.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      B3.config(background="#FFFFFF", foreground="#000000", selectcolor="white")
      enterValue.config(foreground="#000000", background="#FFFFFF", selectbackground="#FF0000")
      label.config(foreground="#000000", background="#FFFFFF")
      buttonSave.config(foreground="#000000", background="#FFFFFF")
      val = 2
   elif val == 2:
      root.config(bg="#080807")
      R1.config(background="#080807", foreground="#FFFFFF", selectcolor="black")
      R2.config(background="#080807", foreground="#FFFFFF", selectcolor="black")
      R3.config(background="#080807", foreground="#FFFFFF", selectcolor="black")
      B1.config(background="#000000", foreground="#FFFFFF", selectcolor="black")
      B2.config(background="#000000", foreground="#FFFFFF", selectcolor="black")
      B3.config(background="#000000", foreground="#FFFFFF", selectcolor="black")
      enterValue.config(foreground="#FFFFFF", background="#484848", selectbackground="#0000FF")
      label.config(foreground="#FFFFFF", background="#484848")
      buttonSave.config(foreground="#FFFFFF", background="#484848")
      val = 1
def callback():
   wb.open("https://www.python.org/")

val = 1
varOne = IntVar()
varTwo = IntVar()

menubar = Menu(root)
menu2 = Menu(menubar, tearoff=0)
menu2.add_command(label="Quitter", command=terminate)
menu2.add_command(label="Changer le thème", command=controlTheme)
menubar.add_cascade(label="OPTIONS", menu=menu2)
menu3 = Menu(menubar, tearoff=0)
menubar.add_cascade(label="AUTRES", menu=menu3)
menu3.add_command(label="Python", command=callback)
varEntryLabel = StringVar()

enterValue = Entry(root, width=58, font=("Trebuchet MS", 14), borderwidth=2, relief="solid", takefocus=5, justify="left", background="#484848", foreground="#FFFFFF", textvariable=varEntryLabel)
varEntryLabel.trace("w", choiceCommand)
label = Label(root, text=(""), background="#484848", foreground="#FFFFFF", font =("Trebuchet MS", 10), relief="solid", width=136, anchor="w")
buttonSave = Button(text="SAVE TO A FILE", command=save, relief="solid", background="#484848", foreground="#FFFFFF", font = ("Helvetica", 8))
root.bind("<Return>", choice)

R1 = Radiobutton(root, text="Binaire", variable=varOne, value=1, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
R2 = Radiobutton(root, text="Héxadécimal", variable=varOne, value=2, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
R3 = Radiobutton(root, text="Octal", variable=varOne, value=3, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
B1 = Radiobutton(root, text="Texte", variable=varTwo, value=1, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
B2 = Radiobutton(root, text="Décimal", variable=varTwo, value=2, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
B3 = Radiobutton(root, text="Héxadécimal", variable=varTwo, value=3, background="#080807", font = ("Verdana", 12), foreground="#FFFFFF", borderwidth=4, overrelief="solid", selectcolor="black")
enterValue.place(x=20, y=5)
buttonSave.place(x=888, y=170)
label.place(x = 20, y = 200)
R1.place(x = 620, y = 5)
R2.place(x = 620, y = 50)
R3.place(x = 620, y = 95)
B1.place(x = 800, y = 5)
B2.place(x = 800, y = 50)
B3.place(x = 800, y = 95)
root.config(menu=menubar)
root.mainloop()