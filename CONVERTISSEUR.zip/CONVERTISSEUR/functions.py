def convertValueToBinary(value):
   newBinaryValue = ""
   if type(value) is str:
      texte = value
      for k in texte:
         valueTemp = ord(k)
         p = 0
         while 2**p <= valueTemp :
            p += 1
         for i in range(p, 0, -1):
            if 2**(i-1) <= valueTemp <= 2**i:
               newBinaryValue += "1" 
               valueTemp -=  2**(i-1)
            else:                        
               newBinaryValue += "0"
         newBinaryValue += " "
   elif type(value) is int or type(value) is float:
      p = 0
      while 2**p <= value :
         p += 1
      for k in range(p, 0, -1):
         if 2**(k-1) <= value <= 2**k:
            newBinaryValue += "1" 
            value -=  2**(k-1)
         else:                        
            newBinaryValue += "0"
   return newBinaryValue

def convertValueToHexadecimal(value):
   newBinaryValue = ""
   newBinaryHexadecimal = ""
   if type(value) is int or type(value) is float:
      p = 0
      while 2**p <= value:
         p += 1
      while p % 4 != 0:
         p += 1
      for k in range(p, 0, -1):  
         if 2**(k-1) <= value <= 2**k:
            newBinaryValue += "1" 
            value -=  2**(k-1)
         else:                        
            newBinaryValue += "0"
         if len(newBinaryValue) == 4:
            listeBinary = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"]
            listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
            indice = 0
            while newBinaryValue != listeBinary[indice]:
               indice += 1
            newBinaryHexadecimal += listeHexadecimal[indice]
            newBinaryValue = ""
   elif type(value) is str:
      texte = value
      for k in texte:
         valueTemp = ord(k)
         p = 0
         while 2**p < valueTemp:
            p += 1
         while p % 4 != 0:
            p += 1
         for k in range(p, 0, -1):  
            if 2**(k-1) <= valueTemp <= 2**k:
               newBinaryValue += "1" 
               valueTemp -=  2**(k-1)
            else:                        
               newBinaryValue += "0"
            if len(newBinaryValue) == 4:
               listeBinary = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"]
               listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
               indice = 0
               while newBinaryValue != listeBinary[indice]:
                  indice += 1
               newBinaryHexadecimal += listeHexadecimal[indice]
               newBinaryValue = ""
         newBinaryHexadecimal += " "

   return newBinaryHexadecimal

def convertValueToOctal(value):
   newBinaryValue = ""
   newBinaryOctal = ""
   if type(value) is int or type(value) is float:
      p = 0
      while 2**p <= value:
         p += 1
      while p % 3 != 0:
         p += 1
      for k in range(p, 0, -1):  
         if 2**(k-1) <= value <= 2**k:
            newBinaryValue += "1" 
            value -=  2**(k-1)
         else:                        
            newBinaryValue += "0"
         if len(newBinaryValue) == 3:
            listeBinary = ["000", "001", "010", "011", "100", "101", "110", "111"]
            listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7"]
            indice = 0
            while newBinaryValue != listeBinary[indice]:
               indice += 1
            newBinaryOctal += listeHexadecimal[indice]
            newBinaryValue = ""
   if type(value) is str:
      texte = value
      for k in texte:
         valueTemp = ord(k)
         p = 0
         while 2**p <= valueTemp:
            p += 1
         while p % 3 != 0:
            p += 1
         for k in range(p, 0, -1):  
            if 2**(k-1) <= valueTemp <= 2**k:
               newBinaryValue += "1" 
               valueTemp -=  2**(k-1)
            else:                        
               newBinaryValue += "0"
            if len(newBinaryValue) == 3:
               listeBinary = ["000", "001", "010", "011", "100", "101", "110", "111"]
               listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7"]
               indice = 0
               while newBinaryValue != listeBinary[indice]:
                  indice += 1
               newBinaryOctal += listeHexadecimal[indice]
               newBinaryValue = ""
         newBinaryOctal += " "
   return newBinaryOctal

def convertHexadecimalToBinary(value):
   code_error = 5
   n = str(value)
   newBinary = ""
   long = len(n)
   listeBinary = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111", "1010", "1011", "1100", "1101", "1110", "1111"]
   listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f"]
   ind = 0
   try:
      for i in range(0, long):
         indice = 0
         while listeHexadecimal[indice] != n[ind]:
            indice += 1
         newBinary += listeBinary[indice]
         ind += 1
   except IndexError:
      return code_error
   except:
      return code_errors
   else:
      return newBinary

def convertHexadecimalToOctal(value):
   n = str(value)
   newBinary = ""
   long = len(n)
   listeBinary = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111", "1010", "1011", "1100", "1101", "1110", "1111"]
   listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "a", "b", "c", "d", "e", "f"]
   ind = 0
   for i in range(0, long):
      indice = 0
      while listeHexadecimal[indice] != n[ind]:
         indice += 1
      newBinary += listeBinary[indice]
      ind += 1
   listePuissance  = []
   longeur = len(newBinary)
   newDecimal = 0
   for k in range(longeur, 0, -1):
      listePuissance.append(2**(k-1))
   for i in range(0, longeur, 1):
      if newBinary[i] == "1":
         newDecimal += listePuissance[i]
   newBinaryValue = ""
   newBinaryOctal = ""
   p = 0
   while 2**p < newDecimal:
      p += 1
   while p % 3 != 0:
      p += 1
   for k in range(p, 0, -1):  
      if 2**(k-1) <= newDecimal <= 2**k:
         newBinaryValue += "1" 
         newDecimal -=  2**(k-1)
      else:                        
         newBinaryValue += "0"
      if len(newBinaryValue) == 3:
         listeBinary = ["000", "001", "010", "011", "100", "101", "110", "111"]
         listeHexadecimal = ["0", "1", "2", "3", "4", "5", "6", "7"]
         indice = 0
         while newBinaryValue != listeBinary[indice]:
            indice += 1
         newBinaryOctal += listeHexadecimal[indice]
         newBinaryValue = ""
   return newBinaryOctal